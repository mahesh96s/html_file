router.get('/contact', (req, res) => {
  res.render('contact')
})